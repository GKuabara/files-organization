#ifndef _FUNCAO_FORNECIDA_H_
#define _FUNCAO_FORNECIDA_H_

void binarioNaTela(char *nomeArquivoBinario);
void scan_quote_string(char *str);

#endif